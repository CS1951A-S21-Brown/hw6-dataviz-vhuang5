const MAX_WIDTH = Math.max(1080, window.innerWidth);
const MAX_HEIGHT = 720;
const margin = {top: 40, right: 100, bottom: 40, left: 300};
const filename = "data/video_games.csv"

let graph_1_width = (MAX_WIDTH / 2) + 30, graph_1_height = 250;
let graph_2_width = (MAX_WIDTH / 2) - 10, graph_2_height = 400;
let graph_3_width = MAX_WIDTH / 2, graph_3_height = 400;